document.createElement('header');
document.createElement('aside');
document.createElement('article');
document.createElement('footer');
document.createElement('section');
document.createElement('figure');
document.createElement('nav');
